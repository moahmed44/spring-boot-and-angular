export class User {
    id: string;
    userName: string;
    password: string;
    repeatPass: string;
    unchangedUserName:  string;
    unchangedPass: string;
    unchangedEmail: string;
    role: string;
    email: string;

    constructor() {

    }

}