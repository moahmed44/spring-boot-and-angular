export class ProductCart {
    id: string;
    userName: string;
    productId: string;

    constructor() {
        
    }
}