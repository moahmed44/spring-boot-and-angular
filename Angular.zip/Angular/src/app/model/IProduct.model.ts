export interface IProduct {
    id? : string,
    numberExtern? : string,
    name? : string,
    type? : string,
    description? : string,
    photo? : string,
    categoryId? : string,
    categoryName? : string,
    price? : string,
}