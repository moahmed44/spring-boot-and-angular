export interface IUser {
    id? : string,
    userName? : string,
    password? : string,
    role? : boolean,
    email? : string
}