export interface IImage {
    id? : string,
    name? : string,
    type? : string,
    description? : string,
    photo? : string,
    categoryId? : string,
    categoryName? : string,
}