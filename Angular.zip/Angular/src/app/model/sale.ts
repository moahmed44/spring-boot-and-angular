export class Sale {
    id: string;
    sale_detail: string;
    total: string;
    installments: string;
    status: string;
    date_approved: string;
    payment_method_id: string;
    payment_type_id: string;
    userName: string;
    userMail: string;
    delivered: boolean;

    constructor() {

    }
}