export interface ICategory {
    id? : string,
    name? : string,
    description? : string,
    photo? : string,
    type? : string
}