import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-carrousel-alternative',
  templateUrl: './carrousel-alternative.component.html',
  styleUrls: ['./carrousel-alternative.component.css']
})
export class CarrouselAlternativeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
