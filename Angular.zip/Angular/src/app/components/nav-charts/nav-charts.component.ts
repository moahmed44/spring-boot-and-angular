import { Component, OnInit } from '@angular/core';
import { SaleServiceService } from './../../services/sale-service/sale-service.service';

@Component({
  selector: 'app-nav-charts',
  templateUrl: './nav-charts.component.html',
  styleUrls: ['./nav-charts.component.css']
})
export class NavChartsComponent implements OnInit {
  
  constructor() { }

  ngOnInit(): void {
  }

}
