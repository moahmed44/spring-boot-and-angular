
export interface IMainComponents {
    showSpinnersLoadData(response): void;
}