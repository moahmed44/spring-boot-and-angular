export const enum Constant {
    SALES = "Venta",
    IMAGES = "Imagenes",
}